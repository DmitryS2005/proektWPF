﻿using LatecomersTracker;
using Newtonsoft.Json;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.IO;
using Microsoft.Win32;




namespace LatecomersTracker
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Latecomer> Latecomers { get; set; }

    private void SaveData()
    {
        var json = JsonConvert.SerializeObject(Latecomers);
        File.WriteAllText("latecomers.json", json);
    }

    // Метод для загрузки данных
    private void LoadData()
    {
        if (File.Exists("latecomers.json"))
        {
            var json = File.ReadAllText("latecomers.json");
            var latecomers = JsonConvert.DeserializeObject<ObservableCollection<Latecomer>>(json);
            foreach (var latecomer in latecomers)
            {
                Latecomers.Add(latecomer);
            }
        }
    }

        public MainWindow()
        {
            InitializeComponent();
            Latecomers = new ObservableCollection<Latecomer>();
            LatecomersDataGrid.ItemsSource = Latecomers;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(NameTextBox.Text))
            {
                Latecomers.Add(new Latecomer
                {
                    Name = NameTextBox.Text,
                    ArrivalTime = DateTime.Now
                });
                NameTextBox.Clear();
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите имя.");
            }
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                Title = "Сохранить данные"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                var json = JsonConvert.SerializeObject(Latecomers);
                File.WriteAllText(saveFileDialog.FileName, json);
            }
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                Title = "Загрузить данные"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Latecomers.Clear(); // Очищаем текущий список перед загрузкой
                var json = File.ReadAllText(openFileDialog.FileName);
                var latecomers = JsonConvert.DeserializeObject<ObservableCollection<Latecomer>>(json);
                foreach (var latecomer in latecomers)
                {
                    Latecomers.Add(latecomer);
                }
            }
        }


        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            // Очищаем коллекцию опоздавших
            Latecomers.Clear();
        }
    }
}

