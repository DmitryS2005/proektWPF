﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace LatecomersTracker.Tests
{
    class Program
    {
        static void Main(string[] args)
        {
            // Arrange: Создаем экземпляр окна и добавляем тестовые данные
            var mainWindow = new MainWindow();
            mainWindow.Latecomers = new ObservableCollection<Latecomer>
            {
                new Latecomer { Name = "Иван Иванов" },
                new Latecomer { Name = "Петр Петров" }
            };

            Console.WriteLine($"До вызова ClearButton_Click: {mainWindow.Latecomers.Count} элементов");

            // Act: Вызываем метод ClearButton_Click
            mainWindow.ClearButton_Click(null, null);

            Console.WriteLine($"После вызова ClearButton_Click: {mainWindow.Latecomers.Count} элементов");

            // Assert: Проверяем, что коллекция пуста
            Debug.Assert(mainWindow.Latecomers.Count == 0, "Тест провален: коллекция не была очищена.");

            // Если тест прошел успешно
            Console.WriteLine("Тест успешно пройден!");
        }
    }
}
