﻿using System;

namespace YourProjectNamespace.Tests
{
    internal class Mock<T>
    {
        internal void Verify(Func<object, object> value, object once)
        {
            throw new NotImplementedException();
        }
    }
}