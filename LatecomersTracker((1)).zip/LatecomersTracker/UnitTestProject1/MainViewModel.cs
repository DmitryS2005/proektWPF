﻿namespace YourProjectNamespace.Tests
{
    internal class MainViewModel
    {
    }
}