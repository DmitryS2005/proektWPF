﻿using System;

namespace LatecomersTracker.Tests
{
    internal class MainWindow
    {
        public MainWindow()
        {
        }

        public System.Collections.ObjectModel.ObservableCollection<Latecomer> Latecomers { get; internal set; }

        internal void ClearButton_Click(object value1, object value2)
        {
            throw new NotImplementedException();
        }
    }
}