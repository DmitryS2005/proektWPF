﻿namespace LatecomersTracker.Tests
{
    internal class Latecomer
    {
        public string Name { get; set; }
    }
}