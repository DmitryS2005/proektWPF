﻿using System;

namespace YourProjectNamespace.Tests
{
    internal class TestFixtureAttribute : Attribute
    {
    }
}